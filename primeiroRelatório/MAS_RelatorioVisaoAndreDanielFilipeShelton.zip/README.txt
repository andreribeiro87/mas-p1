ESTE ZIP CONTÉM:
-RELATÓRIO DE VISÃO EM PDF --> MAS-E2-RelatorioVisaoAndreDanielFilipeShelton.pdf
-PDF COM SCREENSHOTS DO BACKLOG E INFORMAÇÕES DO JIRA --> jiraReportE1AndreDanielFilipeShelton.pdf
-POWERPOINT EM PDF --> E2RelVisaoAndreDanielFilipeShelton.pdf
-POWERPOINT EM PPTX --> E2RelVisao.pptx
-RESPOSTAS AO INQUÉRITO FEITO PARA ESTE PROJETO --> Relatório_de_Visão_MAS_2022_23_G303_(Respostas)_-_Respostas_do_Formulário_1.pdf
-README.txt com informações relativas ao zip


DO GRUPO 3 DA TURMA P3 DE MAS 2022_23

ESPERAMOS QUE TENHA LIDO O README PRIMEIRO

BOA LEITURA PROFESSOR!